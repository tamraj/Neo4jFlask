# Neo4jFlask
REST API in Flask connecting Neo4j database through Bolt protocol.
